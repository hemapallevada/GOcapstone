package validator

import (
	"JazzRentals/model"
	"errors"
	"regexp"
	"time"
)

// DO NOT CHANGE FUNCTION SIGNATURE AND DELETE/COMMENT METHOD
func Validator(booking model.Booking) (bool, error) {
	//Implement your logic here
	if !IsValidCustomerName(booking.CustomerName) {
		return false, errors.New("Please provide a valid name(Ex: John Carter).")
	} else if !IsValidBookingType(booking.TripType) {
		return false, errors.New("Booking Type should either be 'Out-Station' or 'Within-City'.")
	} else if !IsValidDuration(booking.Duration) {
		return false, errors.New("Trip duration should be between 1-7 days!!")
	} else if !IsValidTripStartDate(booking.TripDate) {
		return false, errors.New("The trip date should be within next 12 days from today!!")
	} else {
		return true, nil
	}
}

// DO NOT CHANGE FUNCTION SIGNATURE AND DELETE/COMMENT METHOD
func IsValidCustomerName(customerName string) bool {
	//Implement your logic here
	validatorString := "^[A-Z][a-z]*(([ ][A-Z][a-z]*){0,2})$"
	match, _ := regexp.MatchString(validatorString, customerName)
	return match
}

// DO NOT CHANGE FUNCTION SIGNATURE AND DELETE/COMMENT METHOD
func IsValidTripStartDate(tripDate time.Time) bool {
	//Implement your logic here
	curDate := time.Now()
	dif := tripDate.Sub(curDate)
	if dif.Hours()/24 > 12 {
		return false
	} else {
		return true
	}
}

// DO NOT CHANGE FUNCTION SIGNATURE AND DELETE/COMMENT METHOD
func IsValidBookingType(tripType string) bool {
	//Implement your logic here
	if tripType == "Out-Station" || tripType == "Within-City" {
		return true

	} else {
		return false
	}
}

// DO NOT CHANGE FUNCTION SIGNATURE AND DELETE/COMMENT METHOD
func IsValidDuration(duration int) bool {
	//Implement your logic here
	if duration < 1 || duration > 7 {
		return false
	} else {
		return true
	}

}
