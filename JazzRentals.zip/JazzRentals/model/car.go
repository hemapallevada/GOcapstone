package model

// DO NOT CHANGE STRUCT SIGNATURE AND DELETE/COMMENT
type Car struct {
	ModelName string
	CarType   string
}

// DO NOT CHANGE FUNCTION SIGNATURE AND DELETE/COMMENT
func (car Car) GeneratePrice(duration int) int {
	//Implement your logic here
	var serviceCharge int = 500

	return serviceCharge * duration

}
