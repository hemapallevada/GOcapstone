package model

// DO NOT CHANGE STRUCT SIGNATURE AND DELETE/COMMENT
type VehicleInfo struct {
	ModelName     string
	BookingStatus bool
}
