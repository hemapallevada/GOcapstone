package model

// DO NOT CHANGE INTERFACE SIGNATURE AND DELETE/COMMENT
type Vehicle interface {
	GeneratePrice(duration int) int
}
