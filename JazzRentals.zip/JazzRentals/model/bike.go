package model

// DO NOT CHANGE STRUCT SIGNATURE AND DELETE/COMMENT
type Bike struct {
	ModelName string
	Color     string
}

// DO NOT CHANGE FUNCTION SIGNATURE AND DELETE/COMMENT
func (bike Bike) GeneratePrice(duration int) int {
	//Implement your logic here
	var serviceCharge int = 200
	return duration * serviceCharge
}
