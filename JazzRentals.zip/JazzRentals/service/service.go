package service

import (
	"JazzRentals/model"
	"JazzRentals/repository"
	"JazzRentals/validator"
	"errors"
	"strconv"
	"time"
)

// DO NOT CHANGE FUNCTION SIGNATURE AND DELETE/COMMENT METHOD
func BookTrip(booking *model.Booking) (int, string, error) {
	//Implement your logic here
	valid, err := validator.Validator(*booking)
	if !valid {
		return 0, "NA", err
	} else {
		price := 0
		var ind int
		for ind = 0; ind < len(booking.VehicleList); ind++ {
			cur_veh := booking.VehicleList[ind]
			price += cur_veh.GeneratePrice(booking.Duration)
		}
		bookId := GenerateBookingID(*booking)
		return price, bookId, nil
	}
}

// DO NOT CHANGE FUNCTION SIGNATURE AND DELETE/COMMENT METHOD
func GenerateBookingID(booking model.Booking) string {
	//Implement your logic here
	bookId := ""
	if booking.TripType == "Out-Station" {
		bookId = "OS"
	} else if booking.TripType == "Within-City" {
		bookId = "WC"
	}
	timeNow := time.Now().String()
	timeNow = timeNow[:25]
	timeNow = timeNow[0:4] + timeNow[5:7] + timeNow[8:10] + timeNow[11:13] + timeNow[14:16] + timeNow[17:19] + timeNow[20:]
	bookId = bookId + "-" + strconv.Itoa(booking.Duration) + "-" + timeNow
	return bookId
}

// DO NOT CHANGE FUNCTION SIGNATURE AND DELETE/COMMENT METHOD
func GetVehicleReport(modelName string) ([]model.VehicleInfo, error) {
	//Implement your logic here
	vehicleInfoSlice := repository.VehicleRepository()
	var vehicleInfoAns []model.VehicleInfo
	for _, ele := range vehicleInfoSlice {
		if modelName == ele.ModelName {
			vehicleInfoAns = append(vehicleInfoAns, ele)
		}
	}
	if len(vehicleInfoAns) == 0 {
		return nil, errors.New("There are no vehicles currently available with this model name!!")
	}
	return vehicleInfoAns, nil
}
